#ifndef CASSETUP_H
#define CASSETUP_H

/*	fixed States that must be available in all protocols */
#define	ST_INIT						0
#define	ST_IDLE						1

/*	definition of state init */
#define	INIT_RC_IDLE_CAS			4
#define	INIT_TX_IDLE_CAS			5
#define	INIT_DIAL_PLAN				6
#define	INIT_DTMF_DIAL				7
#define	INIT_COMA_PAUSE_TIME		8
#define	INIT_DTMF_DETECTION			9
#define	INIT_PULSE_DIAL_TIME		10
#define	INIT_PULSE_DIAL				11
#define	INIT_DEBOUNCE				12
#define	INIT_COLLECT_ANI			13
#define	INIT_DIGIT_TYPE				14
#define	NUM_OF_EVENT_IN_STATE		15
#define	INIT_MGCP_REPORT			16
#define	INIT_GLOBAL_TIMERS			17
#define	INIT_GLOBAL_CALL_INFO		18
#define	INIT_PULSE_DIAL_ADDITIONAL_PARAMS 19
#define INIT_RINGING_TO_ANALOGUE	20
#define	INIT_DIGIT_TYPE_1			21

#define	INIT_VERSION				70
#define	INIT_SIZE_OF_TABLE_PARAM	71
#define INIT_REJECT_COLLECT			72

/*	definition of functions */
#define	FUNCTION0					0
#define	FUNCTION1					1
#define	FUNCTION2					2
#define	FUNCTION3					3

#define	EV_PLACE_CALL				4 
#define	EV_TIMER_EXPIRED1			5 
#define	EV_TIMER_EXPIRED2			6 
#define	EV_TIMER_EXPIRED3			7 
#define	EV_TIMER_EXPIRED4			8 
#define	EV_TIMER_EXPIRED5			9 
#define	EV_TIMER_EXPIRED6			10
#define	EV_TIMER_EXPIRED7			11
#define	EV_TIMER_EXPIRED8			12
#define	EV_ANSWER					13
#define	EV_DIAL_TONE_DETECTED		14
#define	EV_DIAL_ENDED				15
#define	EV_DISCONNECT				16
#define	EV_CAS_1_1					17
#define	EV_CAS_1_0					18
#define	EV_CAS_0_1					19
#define	EV_CAS_0_0					20
#define	EV_RB_TONE_STARTED			21
#define	EV_RB_TONE_STOPPED			22
#define	EV_BUSY_TONE				23
#define	EV_FAST_BUSY_TONE			24
//#define	EV_HELLO_DETECTED			25
#define	EV_USER_BLOCK_COMND			25
#define	EV_DIAL_TONE_STOPPED		26
#define	EV_DISCONNECT_INCOMING		27
#define	EV_RELEASE_CALL				28
#define	EV_DIALED_NUM_DETECTED		29
#define	EV_COUNTER1_EXPIRED			30
#define	EV_COUNTER2_EXPIRED			31
#define EV_MFRn_1					32
#define EV_MFRn_2					33
#define EV_MFRn_3					34
#define EV_MFRn_4					35
#define EV_MFRn_5					36
#define EV_MFRn_6					37
#define EV_MFRn_7					38
#define EV_MFRn_8					39
#define EV_MFRn_9					40
#define EV_MFRn_10					41
#define EV_MFRn_11					42
#define EV_MFRn_12					43
#define EV_MFRn_13					44
#define EV_MFRn_14					45
#define EV_MFRn_15					46
#define EV_MFRn_1_STOPED			47
#define EV_MFRn_2_STOPED			48
#define EV_MFRn_3_STOPED			49
#define EV_MFRn_4_STOPED			50
#define EV_MFRn_5_STOPED			51
#define EV_MFRn_6_STOPED			52
#define EV_MFRn_7_STOPED			53
#define EV_MFRn_8_STOPED			54
#define EV_MFRn_9_STOPED			55
#define EV_MFRn_10_STOPED			56
#define EV_MFRn_11_STOPED			57
#define EV_MFRn_12_STOPED			58
#define EV_MFRn_13_STOPED			59
#define EV_MFRn_14_STOPED			60
#define EV_MFRn_15_STOPED			61
#define EV_ANI_NUM_DETECTED			62
#define EV_FIRST_DIGIT				63
#define EV_END_OF_MF_DIGIT			64
#define	EV_ACCEPT					65
#define	EV_REJECT_BUSY				66
#define	EV_REJECT_CONGESTION		67
#define	EV_REJECT_UNALLOCATED		68
#define	EV_REJECT_RESERVE1			69
#define	EV_REJECT_RESERVE2			70
#define	EV_NO_ANI					71
#define	EV_MAKE_METERING_PULSE		72
#define	EV_METERING_TIMER_PULSE_OFF	73
#define	EV_MAKE_FLASH_HOOK			74
#define	EV_SS5_2400					75
#define	EV_SS5_2600					76
#define	EV_SS5_2400_2600			77
#define	EV_SS5_2400_STOP			78
#define	EV_SS5_2600_STOP			79
#define	EV_SS5_2400_2600_STOP		80
#define	EV_FORCED_RELEASE			81
#define	EV_SEIZE_LINE				82
#define	EV_SEND_SEIZE_ACK			83
#define EV_ACCEPT_SPARE_MF1			84
#define EV_ACCEPT_SPARE_MF9			85
#define EV_ACCEPT_SPARE_MF10		86
#define EV_ACCEPT_SPARE_MF11		87
#define EV_ACCEPT_SPARE_MF12		88
#define EV_ACCEPT_SPARE_MF13		89
#define EV_ACCEPT_SPARE_MF14		90
#define EV_ACCEPT_SPARE_MF15		91
#define EV_REJECT_SIT				92
#define	EV_CAS_1_1_1_1				93
#define EV_SEND_WINK_SIGNAL			94

#define EV_SEND_LINE_OPERATOR_SERVICE1	95
#define EV_SEND_LINE_OPERATOR_SERVICE2	96
#define EV_SEND_LINE_OPERATOR_SERVICE3	97
#define EV_SEND_LINE_OPERATOR_SERVICE4	98
#define EV_SEND_LINE_OPERATOR_SERVICE5	99

#define	EV_INIT_CHANNEL				100
#define	EV_BUSY_TONE_STOPPED		101
#define	EV_FAST_BUSY_TONE_STOPPED	102
#define	EV_TO_USER					103

#define EV_SEND_REGISTER_OPERATOR_SERVICE1	104
#define EV_SEND_REGISTER_OPERATOR_SERVICE2	105
#define EV_SEND_REGISTER_OPERATOR_SERVICE3	106
#define EV_SEND_REGISTER_OPERATOR_SERVICE4	107
#define EV_SEND_REGISTER_OPERATOR_SERVICE5	108
#define EV_SEND_REGISTER_OPERATOR_SERVICE6	109


#define	EV_CLOSE_CHANNEL			110 
#define	EV_OPEN_CHANNEL 			111 
#define	EV_FAIL_DIAL	 			112 
#define	EV_FAIL_SEND_CAS 			113 
#define	EV_ALARM					114

#define EV_MAKE_DOUBLE_ANSWER_CAS	115
#define EV_MAKE_DOUBLE_ANSWER_MF	116

#define EV_ANI_REQ_TONE_DETECTED	117
#define	EV_R15_ANI_DETECTED			118
#define EV_DIGIT_IN					119
#define EV_WRONG_MF_LENGTH			120

#define EV_MFRn_0					121
#define EV_ILLEGAL_CAS_VALUE		122

#define EV_USER_0					123
#define EV_USER_1					124
#define EV_USER_2					125
#define EV_USER_3					126

#define	TOTAL_NUMBER_OF_EVENTS		127	/* (EV_WRONG_CAS_VALUE + 1) */
#define	TOTAL_NUMBER_OF_EVENTS_IN_STATE	TOTAL_NUMBER_OF_EVENTS
#define	NUM_OF_ELEMENTS_IN_TABLE	5
#define	MAX_NUM_OF_STATES			52
#define MAX_NUM_OF_OPTIONAL_STATES	150
#define TOTAL_NUMBER_OF_OPTIONAL_EVENTS_IN_STATE 100
#define	OLD_TOTAL_NUMBER_OF_EVENTS	72
#define	OLD_MAX_NUM_OF_STATES		52

#define	EV_TIMER_EXPIRED10			1010
#define	EV_DEBOUNCE_TIMER_EXPIRED	1020
#define	EV_INTER_DIGIT_TIMER_EXPIRED	1030

//Pulse dial detection timers
#define FIRST_PULSE_DIAL_TIMER_NUMBER 2003
#define EV_INTER_DIGITS_MAX_TIMER_EXPIRED 2004
#define EV_PULSE_DIAL_CAS_DEOUNCE_TIMER_EXPIRED 2005
#define EV_SIGNALING_CAS_MIN_TIMER_EXPIRED 2006
#define LAST_PULSE_DIAL_TIMER_NUMBER 2007


#define	SEND_FIRST_DIGIT			104


#define	DO							0
#define	NO_STATE					-1
#define NONE						-1
#define	NO_STATE_CHAR					255
#define NONE_CHAR						255


#define	NILL					0
#define	SET_TIMER				1
#define	SEND_CAS				2
#define	SEND_EVENT				3
#define	SEND_DEST_NUM			4
#define	DEL_TIMER				5
#define	START_COLLECT			6	/* start collect incoming dialed number for number of digits specified in the dial plan */
#define	STOP_COLLECT			7
#define	SEND_MF					8	/* ADDRESS: second parameter describes digit address pointer to send (1 for A1 , -1 for A2 */
									/* SPECIFIC: second parameter describes MF FWD or BWD signal 1-15 to send */
#define	STOP_DIAL_MF			9
#define	SET_COUNTER				10
#define	DEC_COUNTER				11
#define	SEND_PROG_TON			12
#define	CHANGE_COLLECT_TYPE		13
#define	GENERATE_CAS_EV			14  /* for clarent */
#define	SET_PULSE_TIMER			15
#define	SEND_SS5				16  //    param1 freq param2 start/stop
#define RESTRICT_ANI			17


#define NO						0
#define YES						1
#define DTMF					0
#define MF						1
#define PULSE					2
#define SS5_ON					1


#define SEND_FLASH_HOOK_BY_PARAMETER	1


#define NORMAL_PLACE_CALL			NONE
#define PLACE_CALL_AFTER_SEIZURE	1


#define SET_METERING_PULSE_TIMER	0


#define	PULSE_TIMER_OFFSET		69

//	Reporting of events to MGCP
#define	MGCP_Close				0


/*	Call Progress Tone */
#define START_PLAY				1
#define STOP_PLAY				2

/*	MF table function first parameter */
#define ADDRESS					1
#define SPECIFIC				2
#define INTER_EXCHANGE_SWITCH	3
#define ANI						4
#define SOURCE_CATEGORY			5
#define TRANSFER_CAPABILITY		6

/*	Collect type	*/
#define COLLECT_TYPE_ADDRESS			0
#define COLLECT_TYPE_ANI				1
#define COLLECT_TYPE_SOURCE_CATEGORY	2
#define COLLECT_TYPE_LINE_CATEGORY		3

/* paramters for INIT_REJECT_COLLECT */
#define AUTO_REJECT_COLLECT_DISABLE	0
#define AUTO_REJECT_COLLECT_USING_LINE_SIGNALING	1
#define AUTO_REJECT_COLLECT_USING_REGISTER_SIGNALING	2



/* paramters for RESTRICT_ANI */
#define ANI_PRESENTATION_NOT_INCLUDED  -1
#define ANI_PRESENTATION_ALLOWED        0
#define ANI_PRESENTATION_RESTRICTED     1
#define ANI_PRESENTATION_NOT_AVAILABLE  2


/* USABLE EVENTS THAT COULD BE REPORTED TO THE HOST */
#define	acEV_PSTN_INTERNAL_ERROR						64  
#define	acEV_PSTN_CALL_CONNECTED						65  
#define	acEV_PSTN_INCOMING_CALL_DETECTED				66  
#define	acEV_PSTN_CALL_DISCONNECTED						67  
#define	acEV_PSTN_CALL_RELEASED							68  
#define	acEV_PSTN_REMOTE_ALERTING						69  
#define	acEV_PSTN_STARTED								70  
#define	acEV_PSTN_WARNING								71  
#define	acEV_ISDN_PROGRESS_INDICATION					72  		/* ISDN only */
#define	acEV_PSTN_PROCEEDING_INDICATION					73  		
#define	acEV_PSTN_ALARM									74  
#define	acEV_RESERVED									75  
#define	acEV_PSTN_LINE_INFO								76  
#define	acEV_PSTN_LOOP_CONFIRM							77  
#define	acEV_PSTN_RESTART_CONFIRM						78  

#define	acEV_ISDN_SETUP_ACK_IN							84			/* ISDN only */
#define	acEV_PSTN_CALL_INFORMATION						85


#define acEV_PSTN_LAST_RECEIVED_CAS						97
#define	acEV_PSTN_METERING								98


#define	acEV_CAS_SEIZURE_DETECTED						128
#define	acEV_CAS_CHANNEL_BLOCKED						129
#define	acEV_CAS_PROTOCOL_STARTED						130
#define	acEV_PSTN_CALL_STATE_RESPONSE					131
#define	acEV_CAS_SEIZURE_ACK							132

#define acEV_CAS_FLASH_HOOK_DETECTED	                136

#define acEV_CAS_CALL_SUSPENDED							289
#define acEV_CAS_CALL_RESUMED							290

#define acEV_CAS_USER_INFO_INDICATION					449

#define acEV_WINK_DETECTION								1401
#define acEV_PSTN_OPERATOR_SERVICE						1402

/* CAUSES TO USE IN THE CAS PROTOCOLS (USER CAN ADD SPECIFIC CAUSES AT THE USER_PROTOCOLDEFINES.H FILE */
#define RB_STOPPED										0 /* used at comment field in acEV_PSTN_REMOTE_ALERTING */
#define RB_STARTED										1 /* used at comment field in acEV_PSTN_REMOTE_ALERTING */

/* CAUSES to user for acEV_PSTN_PROCEEDING_INDICATION event, relevant for MFCR2 only. */
#define SERVICE_CHARGE					0 /* This signal permits non-chargeable calls without the need for transferring "no charge" information by the lines. */
#define SERVICE_FREE					1 /* Call has to be charged on answer. */
#define SPARE_MF_9						2
#define SPARE_MF_10						3
#define SPARE_MF_11						4
#define SPARE_MF_12						5
#define SPARE_MF_13						6
#define SPARE_MF_14						7
#define SPARE_MF_15						8
#define SPARE_MF_1						9

/* CAUSE OF BLOCK */
#define REMOTE_SIDE						1
#define LOCAL_SIDE						2

/* Normal event - class 000 */
#define	UNASSIGNED_NUMBER   							1
#define	NO_ROUTE_TO_TRANSIT_NET	  						2
#define	NO_ROUTE_TO_DESTINATION   						3
#define	CHANNEL_UNACCEPTABLE   							6
#define	CALL_AWARDED_AND   								7
#define	PREEMPTION   									8  	/* Added in ETS 300 403 */


/*	CAS Dat header filles	*/
#define	OLD_CAS_TABLE_MAGIC_NUM   						0xEF78EF78
#define	NEW_CAS_TABLE_MAGIC_NUM   						0xEF79EF79
#define	DYNAMIC_CAS_TABLE_MAGIC_NUM   					0xEF80EF80
#define OLD_CAS_TABLE_NAME_OFFSET						0x11C
#define NEW_CAS_TABLE_NAME_OFFSET						0x3C
#define DYNAMIC_CAS_TABLE_NAME_OFFSET					0x3C
#define	NEW_CAS_TABLE_NUM_OF_STATES						32*sizeof(int)
#define	NEW_CAS_TABLE_NUM_OF_EVENTS						33*sizeof(int)
#define	NEW_CAS_TABLE_NUM_OF_ELEMENTS_IN_EVENT			34*sizeof(int)
#define	DYNAMIC_CAS_TABLE_NUM_OF_STATES					sizeof(int)
#define	DYNAMIC_CAS_TABLE_NUM_OF_EVENTS					2*sizeof(int)


#define CAS_TABLE_FILE_LENGHT_OFFSET					2*sizeof(int)
#define CAS_TABLE_DATA_OFFSET							1*sizeof(int)


/* Normal event - class 001 */
#define	NORMAL_CALL_CLEAR   							16   
#define	USER_BUSY   									17   
#define	NO_USER_RESPONDING   							18   
#define	NO_ANSWER_FROM_USER_ALERTED	  					19   
#define	ACCEPT_DONE		   								20  
#define	CALL_REJECTED   								21  
#define	NUMBER_CHANGED   								22  
#define	NON_SELECTED_USER_CLEARING   					26  
#define	DEST_OUT_OF_ORDER   							27  
#define	INVALID_NUMBER_FORMAT   						28  
#define	FACILITY_REJECT	   								29  
#define	RESPONSE_TO_STATUS_ENQUIRY   					30  
#define	NORMAL_UNSPECIFIED   							31  
#define	CIRCUIT_CONGESTION								32
#define	USER_CONGESTION									33

/* Resource not available */
#define	NO_CIRCUIT_AVAILABLE   							34  
#define	NETWORK_OUT_OF_ORDER   							38  
#define	NETWORK_TEMPORARY_FAILURE   					41  
#define	NETWORK_CONGESTION   							42  
#define	ACCESS_INFORMATION_DISCARDED   					43  
#define	REQUESTED_CIRCUIT_NOT_AVAILABLE   				44  
#define	RESOURCE_UNAVAILABLE_UNSPECIFIED	  			47  
#define	PERM_FR_MODE_CONN_OUT_OF_S   					39  		/* Added in ETS 300 403 */
#define	PERM_FR_MODE_CONN_OPERATIONAL   				40  		/* Added in ETS 300 403 */
#define	PRECEDENCE_CALL_BLOCKED   						46  		/* Added in ETS 300 403 */

/* Service not available */
#define	QUALITY_OF_SERVICE_UNAVAILABLE		 			49  
#define	REQUESTED_FAC_NOT_SUBSCRIBED   					50  
#define	BC_NOT_AUTHORIZED   							57  
#define	BC_NOT_PRESENTLY_AVAILABLE   					58  
#define	SERVICE_NOT_AVAILABLE   						63  
#define	CUG_OUT_CALLS_BARRED   							53  			/* Added in ETS 300 403 */
#define	CUG_INC_CALLS_BARRED   							55  			/* Added in ETS 300 403 */
#define	ACCES_INFO_SUBS_CLASS_INCONS	   				62  			/* Added in ETS 300 403 */

/* Service not implemented */
#define	BC_NOT_IMPLEMENTED   							65  
#define	CHANNEL_TYPE_NOT_IMPLEMENTED   				    66  
#define	REQUESTED_FAC_NOT_IMPLEMENTED   				69  
#define	ONLY_RESTRICTED_INFO_BEARER   					70  
#define	SERVICE_NOT_IMPLEMENTED_UNSPECIFIED   			79  

/* Invalid message */
#define	INVALID_CALL_REF   								81  
#define	IDENTIFIED_CHANNEL_NOT_EXIST   					82  
#define	SUSPENDED_CALL_BUT_CALL_ID_NOT_EXIST   			83  
#define	CALL_ID_IN_USE   								84  
#define	NO_CALL_SUSPENDED   							85  
#define	CALL_HAVING_CALL_ID_CLEARED						86  
#define	INCOMPATIBLE_DESTINATION   						88  
#define	INVALID_TRANSIT_NETWORK_SELECTION				91  
#define	INVALID_MESSAGE_UNSPECIFIED   					95  
#define	NOT_CUG_MEMBER   								87  		/* Added in ETS 300 403 */
#define	CUG_NON_EXISTENT   								90  		/* Added in ETS 300 403 */

/* Protocol error */
#define	MANDATORY_IE_MISSING   							96  
#define	MESSAGE_TYPE_NON_EXISTENT						97  
#define	MESSAGE_STATE_INCONSISTENCY   					98  
#define	NON_EXISTENT_IE   								99  
#define	INVALID_IE_CONTENT   							100  
#define	MESSAGE_NOT_COMPATIBLE   						101  
#define	RECOVERY_ON_TIMER_EXPIRY   						102  
#define	PROTOCOL_ERROR_UNSPECIFIED   					111  

/* Interworking */
#define	INTERWORKING_UNSPECIFIED   						127  

/* not Q.931 causes*/
#define	ACU_CAUSE_ACU_BAD_ADDRESS   					128	 /*0xF0,*/	/* value 0: bad context addressing info, or no free context available */
#define	ACU_CAUSE_ACU_BAD_SERVICE   					129	 /*0xF1,*/	/* value 1: bad ACU service value */
#define	ACU_CAUSE_ACU_COLLISION   						130	 /*0xF2,*/	/* value 2: incoming call collision */
#define	ACU_CAUSE_ACU_FAC_REJECTED   					131	 /*0xF3,*/	/* value 3: Facility request rejected by ACU */
#define	ACU_NETWORK_CAUSE_NIL   						255	 /*0xFF,*/	/* value F: unspecified */

/* return codes causes by AudioCodes/Omnitel */
#define	C_ALREADY_BLOCKED								200
#define	C_CHANNEL_BLOCKED								201
#define	C_BLOCKING_DONE									202 
#define	C_ALREADY_UNBLOCKED								203
#define	C_UNBLOCKING_DONE								204



#define	ACURC_BUSY   									300		/* busy */
#define	ACURC_NOPROCEED	  								301		/* no proceed indication (dial tone) */
#define	ACURC_NOANSWER									302		/* no answer */
#define	ACURC_NOAUTOANSWER	 							303		/* no auto-answer tone detected */
#define	ACURC_CONGESTED									304		/* GSTN or System is congested */
#define	ACURC_INCOMING		 							305		/* incoming call detected while try to dial */
#define	ACURC_NOLINE   									306		/* (analog) line is seized by another equipment */
																/* (ISDN) Wrong Addressing info, or context already used */
#define	ACURC_ERRNUM   									307		/* errored number */
#define	ACURC_INHNUM   									308		/* inhibited number */
#define	ACURC_2MNUM   							 		309		/* too many errored/inhibited numbers */
#define	ACURC_HUNGUP   									310		/* remote has hung up or incident on connection */
#define	ACURC_NETWORK_ERROR   							311		/* (ISDN) network disconnected us */
#define	ACURC_TIMEOUT   								312		/* time-out error */
#define	ACURC_BAD_SERVICE   							313		/* Bad Service-id in ACU_CONN_RQ/RS */
#define	ACURC_INTERNAL   								314		/* other internal error */

#define	ACURC_OK   										315		/* No error */
#define	ACURC_BL_TIMEOUT	   							316		/* BL time-out error */
#define	ACURC_IN_CALL   								317		/* BL error, still in call */
#define	ACURC_CLEAR_RQ   								318		/* User entity requested CLEAR */


/* Add Events for ATM CAS Translation */

#define	EV_CAS_0000     			0 
#define	EV_CAS_0001     			1 
#define	EV_CAS_0010     			2 
#define	EV_CAS_0011     			3 
#define	EV_CAS_0100     			4 
#define	EV_CAS_0101     			5 
#define	EV_CAS_0110     			6 
#define	EV_CAS_0111     			7 
#define	EV_CAS_1000     			8 
#define	EV_CAS_1001     			9 
#define	EV_CAS_1010     			10 
#define	EV_CAS_1011     			11 
#define	EV_CAS_1100     			12
#define	EV_CAS_1101     			13 
#define	EV_CAS_1110     			14 
#define	EV_CAS_1111     			15 
#define CAS_AUTO_ACT				16
#define CAS_AUTO_DEACT				17
#define CAS_IDLE                                18

#define	DO_CAS_0000     			0 
#define	DO_CAS_0001     			1 
#define	DO_CAS_0010     			2 
#define	DO_CAS_0011     			3 
#define	DO_CAS_0100     			4 
#define	DO_CAS_0101     			5 
#define	DO_CAS_0110     			6 
#define	DO_CAS_0111     			7 
#define	DO_CAS_1000     			8 
#define	DO_CAS_1001     			9 
#define	DO_CAS_1010     			10 
#define	DO_CAS_1011     			11 
#define	DO_CAS_1100     			12
#define	DO_CAS_1101     			13 
#define	DO_CAS_1110     			14 
#define	DO_CAS_1111     			15 
#define DO_CAS_NONE					255


#define acOPERATOR_RELEASED		1
#define acOPERATOR_ATTACHED		2
#define acOPERATOR_COIN_COLLECT	3
#define acOPERATOR_COIN_RETURN	4
#define acOPERATOR_RING_BACK	5


#define Increment	0
#define decrement	NONE


#define UseCASOperatorServiceEnumeration 99


#endif	/* CASSETUP_H */
